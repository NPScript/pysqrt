# Pysqrt

Pysqrt is a little algorithm to calculate the square root.
